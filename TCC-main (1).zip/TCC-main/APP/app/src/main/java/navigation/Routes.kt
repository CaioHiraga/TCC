package navigation

object Routes {
    val home = "home"
    val login = "login"
    val signup = "sigup"
    val maingest = "maingest"
    val perguntas = "perguntas"
    val planoparto = "planoparto"
    val perfil = "perfil"
    val acompanhamento = "acompanhamento"
    val calendario = "calendario"
}