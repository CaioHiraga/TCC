# Curso Superior de Tecnologia em Análise e Desenvolvimento de Sistemas 
## TCC - Projeto da caderneta pré natal
### Participantes
> Caio Yuzo Hiraga
> 
> Gabriel Kauê Caitano Alves

### Instruções para dowload do trabalho
# Build(recomendado depuração pelo celular)
> Abra o projeto no android e rode o aplicativo pelo android studio

# APK
> Baixe o projeto e rode o app-debug-androidTest.apk no seu celular
